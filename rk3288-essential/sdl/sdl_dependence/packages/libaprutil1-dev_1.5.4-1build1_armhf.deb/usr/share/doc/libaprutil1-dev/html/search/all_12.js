var searchData=
[
  ['uri',['URI',['../group___a_p_r___util___u_r_i.html',1,'']]],
  ['uuid_20handling',['UUID Handling',['../group___a_p_r___u_u_i_d.html',1,'']]],
  ['uptime',['uptime',['../structapr__memcache__stats__t.html#aec6db8440a51aabfbfaf2130ec5a78bb',1,'apr_memcache_stats_t']]],
  ['user',['user',['../structapr__uri__t.html#a2b763f50bec4fda0cf67e5238275b5fd',1,'apr_uri_t']]]
];
