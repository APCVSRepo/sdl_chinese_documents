var searchData=
[
  ['sdbm_20library',['SDBM library',['../group___a_p_r___util___d_b_m___s_d_b_m.html',1,'']]],
  ['string_20matching_20routines',['String matching routines',['../group___a_p_r___util___str_match.html',1,'']]],
  ['status_20value_20tests',['Status Value Tests',['../group___a_p_u___s_t_a_t_u_s___i_s.html',1,'']]]
];
