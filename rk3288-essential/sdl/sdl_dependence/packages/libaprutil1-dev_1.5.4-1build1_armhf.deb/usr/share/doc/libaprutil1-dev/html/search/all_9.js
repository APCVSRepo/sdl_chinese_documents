var searchData=
[
  ['ldap',['LDAP',['../group___a_p_r___util___l_d_a_p.html',1,'']]],
  ['lang',['lang',['../structapr__xml__elem.html#a9a48a384f579816f62a7369aeb8b1a0c',1,'apr_xml_elem']]],
  ['last',['last',['../structapr__text__header.html#a3ebe57b46d323b8cefaba1e114acf09e',1,'apr_text_header']]],
  ['last_5fchild',['last_child',['../structapr__xml__elem.html#ad4f49811fc36f2377c72ac2c19e57abd',1,'apr_xml_elem']]],
  ['length',['length',['../structapr__bucket.html#a0898dfc78d9275187189b9a745e619bf',1,'apr_bucket::length()'],['../structapr__strmatch__pattern.html#a4b1f44db089850f396bc4bedac0fb25c',1,'apr_strmatch_pattern::length()']]],
  ['limit_5fmaxbytes',['limit_maxbytes',['../structapr__memcache__stats__t.html#afbfa184ab0898d4a897a629c935783b8',1,'apr_memcache_stats_t']]],
  ['list',['list',['../structapr__bucket.html#a5a500b80105834621514d6c0814d0966',1,'apr_bucket::list()'],['../structapr__bucket__pool.html#a651aa0c18658342daf72ff86680bfaca',1,'apr_bucket_pool::list()']]],
  ['live_5fservers',['live_servers',['../structapr__memcache__t.html#a85f916183d0aae6aaa88251edc7a1f81',1,'apr_memcache_t']]],
  ['local',['local',['../structapr__sha1__ctx__t.html#aaa8433058ac7a3b0649821cbab7de822',1,'apr_sha1_ctx_t']]],
  ['lock',['lock',['../structapr__memcache__server__t.html#aab472a87e5f0abe993e565a8e3a72490',1,'apr_memcache_server_t']]]
];
