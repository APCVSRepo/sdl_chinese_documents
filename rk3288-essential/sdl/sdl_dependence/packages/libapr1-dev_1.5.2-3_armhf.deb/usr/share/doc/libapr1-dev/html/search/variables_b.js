var searchData=
[
  ['nalloc',['nalloc',['../structapr__array__header__t.html#a0ceb78a23ebef1bceea5f0cd3e1513b6',1,'apr_array_header_t']]],
  ['name',['name',['../structapr__finfo__t.html#a2915f9141ea76ae3672ccf9eb0fa77bb',1,'apr_finfo_t::name()'],['../structapr__getopt__option__t.html#a7e623913c9761495c5d37adf6ff1ee69',1,'apr_getopt_option_t::name()']]],
  ['nelts',['nelts',['../structapr__array__header__t.html#ab11b88220885c5a0920a06ac85680055',1,'apr_array_header_t']]],
  ['next',['next',['../structapr__memnode__t.html#a07dd84ca152164d6bc283dbce99f8f78',1,'apr_memnode_t::next()'],['../structapr__sockaddr__t.html#a774835c6b8e3adf255b752e8b126c434',1,'apr_sockaddr_t::next()']]],
  ['nlink',['nlink',['../structapr__finfo__t.html#a98598f28735d75aa0c1994efc825e6d9',1,'apr_finfo_t']]],
  ['numheaders',['numheaders',['../structapr__hdtr__t.html#a8915ade68ef06f4d23005ec0f81e9305',1,'apr_hdtr_t']]],
  ['numtrailers',['numtrailers',['../structapr__hdtr__t.html#a9468659de891a5672b0b84cf442e9c7b',1,'apr_hdtr_t']]]
];
