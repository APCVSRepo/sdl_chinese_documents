var searchData=
[
  ['addr_5fstr_5flen',['addr_str_len',['../structapr__sockaddr__t.html#a8f7cda5562e904a1398ed5a4a6f0a9d9',1,'apr_sockaddr_t']]],
  ['apr_5fday_5fsnames',['apr_day_snames',['../group__apr__time.html#ga37d6f7740ae0f5d8ae9cfc286e8712be',1,'apr_time.h']]],
  ['apr_5fmonth_5fsnames',['apr_month_snames',['../group__apr__time.html#ga77382d017a2bef80d44478e0b41557a4',1,'apr_time.h']]],
  ['argc',['argc',['../structapr__getopt__t.html#a58aeb33137aabdd5a00efbde05652094',1,'apr_getopt_t']]],
  ['argv',['argv',['../structapr__getopt__t.html#a296c27d8db2fe6d4b88c5c7a85c40c02',1,'apr_getopt_t']]],
  ['atime',['atime',['../structapr__finfo__t.html#ad78874e5751e9bba30debb0826eb96a7',1,'apr_finfo_t']]]
];
