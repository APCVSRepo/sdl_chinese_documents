var searchData=
[
  ['global_20locking_20routines',['Global Locking Routines',['../group___a_p_r___global_mutex.html',1,'']]],
  ['general_20purpose_20library_20routines',['General Purpose Library Routines',['../group__apr__lib.html',1,'']]]
];
