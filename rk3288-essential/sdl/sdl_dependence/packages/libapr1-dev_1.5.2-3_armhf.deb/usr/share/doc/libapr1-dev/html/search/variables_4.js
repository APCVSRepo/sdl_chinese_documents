var searchData=
[
  ['f',['f',['../unionapr__descriptor.html#a69d605f2bb33b05ceedb3d95b744ca7e',1,'apr_descriptor']]],
  ['family',['family',['../structapr__sockaddr__t.html#ac17f6e803928cfc29069a6e62dcb3a52',1,'apr_sockaddr_t::family()'],['../structapr__os__sock__info__t.html#aa29fd0cf57b0b5e3559961f068fa8b7e',1,'apr_os_sock_info_t::family()']]],
  ['filehand',['filehand',['../structapr__finfo__t.html#a7858e3d9c5f6ed062d9ff7f5c79b6336',1,'apr_finfo_t']]],
  ['filetype',['filetype',['../structapr__finfo__t.html#a274ae0dd60b59182c2e0134bc9a09a20',1,'apr_finfo_t']]],
  ['first_5favail',['first_avail',['../structapr__memnode__t.html#a863e7980225e46678881271c4c803e4c',1,'apr_memnode_t']]],
  ['fname',['fname',['../structapr__finfo__t.html#acfed83ab2943ee7a58a215aa1cfd9e47',1,'apr_finfo_t']]],
  ['free_5findex',['free_index',['../structapr__memnode__t.html#af63769f30f6eb9d72e4b24050bd7a9d9',1,'apr_memnode_t']]]
];
